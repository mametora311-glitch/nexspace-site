window.AIEC_CONFIG = {
  COMPANY_NAME: "Nexspace",
  SUPPORT_EMAIL: "support@example.com",
  PAYMENT_LINK_URL: "",
  PRICE_ID: "",
  DOWNLOAD_URL_WINDOWS: "",
  DOWNLOAD_URL_LINUX: "",
  NOTES_TOKEN_CAP: "月間300k tokens（生成+レビュー合算）",
};
